%{
This MATLAB script is to reproduce statistical analyses presented in Kim et al., 2025, ManyMusic: An Open-access Music
Audio Dataset for Human Experiments on Musical Emotions, HCMIR25.

https://manymusic.net/stim/
(CC4-BY) seung-goo.kim@ae.mpg.de
%}

clear
load([DN_PROJ,'/data/prolific-v2/proc/tbl-lme.mat'], 'TblLme')

%% t-test: SELF- vs. EXPERIMENTER-selected tracks
TblLme = join(Results.TblRatings, Results.TblSubjects(:,["MTr_val", "Emo_val", "subjectId"]));
clc
for thisScale = ["professionalism", "familiarity", "valence", "arousal", "liking", "moved"]
  Mdl0 = fitlme(TblLme, thisScale + ...
    "_val ~ source + Age + Sex + MTr_val + Emo_val + (1 + isThisExpMyGenre | subjectId) + (1 | trackId)")
end

%% F-test: Effects of SOURCE
TblLme(TblLme.source=='Self',:) = []; % except for self-selected
TblLme.source = removecats(TblLme.source, 'Self');
clc
for thisScale = ["professionalism", "familiarity", "valence", "arousal", "liking", "moved"]
  Mdl0 = fitlme(TblLme, thisScale + ...
    "_val ~ source + Age + Sex + MTr_val + Emo_val + (1 + isThisExpMyGenre | subjectId) + (1 | trackId)");
  a = anova(Mdl0);
  F = a(2,2).FStat;
  df1 = a(2,3).DF1;
  df2 = a(2,4).DF2;
  eta_p = (F*df1) / (F*df1 + df2);

  fprintf('%s: F[%i,%i] = %.2f, eta_p=%.3f, P=%s\n', thisScale, df1, df2, F, eta_p, formatpval(a(2,5).pValue))
end